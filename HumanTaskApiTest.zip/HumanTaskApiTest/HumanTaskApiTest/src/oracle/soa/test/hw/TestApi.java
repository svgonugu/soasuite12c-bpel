package oracle.soa.test.hw;

import java.util.HashMap;
import java.util.Map;

import oracle.bpel.services.common.util.XMLUtil;
import oracle.bpel.services.workflow.client.IWorkflowServiceClient;
import oracle.bpel.services.workflow.client.IWorkflowServiceClientConstants.CONNECTION_PROPERTY;
import oracle.bpel.services.workflow.client.WorkflowServiceClientFactory;
import oracle.bpel.services.workflow.task.IInitiateTaskResponse;
import oracle.bpel.services.workflow.task.model.ObjectFactory;
import oracle.bpel.services.workflow.task.model.Task;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class TestApi
{
   //admin credentials
   private static final String wlsUser = "weblogic";
   private static final String wlsPassword = "weblogic1";

   //soa-infra url
   private static final String soaURL = "http://svgonugu-lap.oradev.oraclecorp.com:7005/soa-infra";
      //"http://localhost:7005/soa-infra";

   //task namespace from .task file
   private static final String taskNameSpace =
      "http://xmlns.oracle.com/expenses/approval/approvaltask";
   
   public static void main(String[] args)
   {
      TestApi testApi = new TestApi();
      testApi.createHumanTask();
   }
   
   private Map<CONNECTION_PROPERTY, String> getClientProp(String clientType)
   {
      Map<CONNECTION_PROPERTY, String> properties = new HashMap<CONNECTION_PROPERTY, String>();

      if (WorkflowServiceClientFactory.REMOTE_CLIENT.equals(clientType))
      {
         properties.put(CONNECTION_PROPERTY.EJB_INITIAL_CONTEXT_FACTORY,
                        "weblogic.jndi.WLInitialContextFactory");

         //soa-infra url
         properties.put(CONNECTION_PROPERTY.EJB_PROVIDER_URL, soaURL);

         //admin user
         properties.put(CONNECTION_PROPERTY.EJB_SECURITY_PRINCIPAL, wlsUser);

         //admin pwd
         properties.put(CONNECTION_PROPERTY.EJB_SECURITY_CREDENTIALS, wlsPassword);
      }
      else if (WorkflowServiceClientFactory.SOAP_CLIENT.equals(clientType))
      {
         properties.put(CONNECTION_PROPERTY.SOAP_END_POINT_ROOT, "http://svgonugu-lap.oradev.oraclecorp.com:7005");
         properties.put(CONNECTION_PROPERTY.SOAP_IDENTITY_PROPAGATION, "non-saml");
      }
      return properties;
   }

   private IWorkflowServiceClient getWfServiceClient()
   {
      IWorkflowServiceClient wfSvcClient = null;

      wfSvcClient =
         WorkflowServiceClientFactory.getWorkflowServiceClient(WorkflowServiceClientFactory.SOAP_CLIENT,
                                                               getClientProp(WorkflowServiceClientFactory.SOAP_CLIENT),
                                                               null);
      //WorkflowServiceClientFactory.getWorkflowServiceClient(WorkflowServiceClientFactory.REMOTE_CLIENT);

      return wfSvcClient;
   }

   private Element getTaskPayload()
      throws Exception
   {
      String payloadStr =
         "  <payload xmlns=\"http://xmlns.oracle.com/bpel/workflow/task\">" +
         "<EmployeeExpenseInput xmlns=\"http://xmlns.oracle.com/expenses/approval/schema\">" +
         "  <employeeId></employeeId> " + "  <firstName></firstName> " + "  <lastName></lastName>" +
         "  <expenseType></expenseType>" + "  <expenseDescription></expenseDescription>" +
         "  <expenseLocation></expenseLocation>" + "  <expenseDate></expenseDate>" +
         "  <amount></amount>" + "</EmployeeExpenseInput>" + "  </payload>";
      Document doc = null;

      try
      {
         doc = XMLUtil.parseDocumentFromXMLString(payloadStr);
      }
      catch (Exception e)
      {
         throw new Exception("Exception in parsing string to xml");
      }
      return doc.getDocumentElement();
   }

   public String createHumanTask()
   {
      String taskId = null;
      IInitiateTaskResponse taskResponse = null;

      try
      {
         ObjectFactory of = new ObjectFactory();
         Task newTask = of.createTask();

         //set required attribute before calling BPM task api
         newTask.setTaskDefinitionId(taskNameSpace);
         newTask.setPayloadAsElement(getTaskPayload());
         newTask.setCreator(wlsUser);
         newTask.setTitle("BPM API TESTING USING CREATE HUMAN TASK");
         newTask.setCategory("TESTING");
         newTask.setIdentificationKey("587776676");

         taskResponse = getWfServiceClient().getTaskService().initiateTask(newTask);

         if (taskResponse != null)
         {
            newTask = taskResponse.getTask();
            taskId = newTask.getSystemAttributes().getTaskId();
         }
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return taskId;
   }
}
